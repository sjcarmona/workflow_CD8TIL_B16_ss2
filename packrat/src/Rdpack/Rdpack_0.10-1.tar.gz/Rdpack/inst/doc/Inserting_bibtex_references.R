### R code from vignette source 'Inserting_bibtex_references.Rnw'

###################################################
### code chunk number 1: Inserting_bibtex_references.Rnw:19-21
###################################################
library(Rdpack)
pd <- packageDescription("Rdpack")


