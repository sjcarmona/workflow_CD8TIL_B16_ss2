require("HDF5Array") || stop("unable to load HDF5Array package")
HDF5Array:::.test()
