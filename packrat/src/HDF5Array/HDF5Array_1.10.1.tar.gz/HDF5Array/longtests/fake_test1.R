cat("This fake test doesn't test anything...\n")

stop("... and FAILS!\n")

cat("(miserably)\n")

