cat("This fake test doesn't test anything...\n")

cat("... and succeeds.\n")

