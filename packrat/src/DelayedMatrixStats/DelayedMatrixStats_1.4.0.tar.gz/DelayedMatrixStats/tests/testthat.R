library(testthat)
library(DelayedMatrixStats)

test_check("DelayedMatrixStats")
setAutoBlockSize(8)
test_check("DelayedMatrixStats")
