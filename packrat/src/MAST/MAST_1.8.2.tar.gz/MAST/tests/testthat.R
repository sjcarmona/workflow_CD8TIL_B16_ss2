library(testthat)
test_check("MAST")
