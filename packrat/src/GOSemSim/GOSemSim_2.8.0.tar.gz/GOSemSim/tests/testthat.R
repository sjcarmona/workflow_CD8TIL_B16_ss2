library(testthat)
library(GOSemSim)

test_check("GOSemSim")
