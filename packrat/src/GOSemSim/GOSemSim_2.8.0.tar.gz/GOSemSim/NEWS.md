# GOSemSim 2.7.1

+ `mgeneSim` and `mclusterSim` now always return matrix (2018-08-08, Wed)
    - <https://www.biostars.org/p/330642/#331598>
# GOSemSim 2.5.1

+ return NA for deprecated IDs (2018-01-09, Fri)
    - <https://support.bioconductor.org/p/105822/#105840>
