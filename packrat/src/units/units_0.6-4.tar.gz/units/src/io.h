void r_error_fn(const char* fmt, va_list args);
void handle_error(const char *calling_function);
