##' @importFrom ggplot2 ggtitle
##' @export
ggplot2::ggtitle

##' @importFrom cowplot plot_grid
##' @export
cowplot::plot_grid
