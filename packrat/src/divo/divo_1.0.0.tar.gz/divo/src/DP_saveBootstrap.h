void DP_saveBootstrap(int** ptrAfa,int* ptrdimAfa);
