void OL_draw_arrays(int* ptrX,int nAfa1D,double* ptrSizee,int* ptrAfa1D);	
