double OL_cvg(int* ptrCol,int* ptrdimAfa);
