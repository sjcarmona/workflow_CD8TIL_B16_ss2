double OL_RDS(int* ptrIcol,int* ptrJcol,int* ptrdimAfa,double Alpha);
