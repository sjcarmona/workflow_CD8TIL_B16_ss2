int DP_read(SEXP X, SEXP Test, SEXP Alpha, SEXP Resample, SEXP CI, 
		  SEXP Faaa, SEXP PlugIn, SEXP Sizee, SEXP AlphaPro, SEXP CVG, 
		  SEXP BS, SEXP OutMean, SEXP OutMin, SEXP OutMax, SEXP OutCvg);
