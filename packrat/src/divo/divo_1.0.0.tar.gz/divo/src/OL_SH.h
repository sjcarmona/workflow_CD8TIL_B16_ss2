double OL_SH(double* ptrVec,int nVec);
