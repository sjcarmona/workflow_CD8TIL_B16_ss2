double OL_cvg_IN(int* ptrAfa1D,int nAfa1D);
