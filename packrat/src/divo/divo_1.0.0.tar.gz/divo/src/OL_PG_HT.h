double OL_PG_HT(int* ptrIcol,int* ptrJcol,int* ptrdimAfa,double Alpha,double Beta);
