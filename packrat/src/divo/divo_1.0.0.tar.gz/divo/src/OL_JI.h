double OL_JI(int* ptrIcol,int* ptrJcol,int* ptrdimAfa);
