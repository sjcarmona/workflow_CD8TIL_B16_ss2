void DP_confidence_interval(double** ptrResults,int* ptrdimResults,double valCI,
	double* ptrOutMean,int* ptrdimOutMean,double* ptrOutMin,int* ptrdimOutMin,double* ptrOutMax,int* ptrdimOutMax);
