double OL_I_Index(int* ptrIcol,int* ptrJcol,int* ptrdimAfa,double Alpha);
