void OL_saveBootstrap(int** ptrAfa,int* ptrdimAfa);
