void DP_single_population(int* ptrCol,int* ptrdimAfa,double* ptrAlphaPro,int nAlphaPro,int ENS,double* ptrResults);
