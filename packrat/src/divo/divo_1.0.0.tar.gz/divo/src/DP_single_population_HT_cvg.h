void DP_single_population_HT_cvg(int* ptrCol,int* ptrdimAfa,double* ptrAlphaPro,int nAlphaPro,int ENS,double valOutCvg,double* ptrResults);
