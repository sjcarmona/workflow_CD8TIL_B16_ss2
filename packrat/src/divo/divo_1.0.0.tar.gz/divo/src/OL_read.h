int OL_read(SEXP X, SEXP Test, SEXP Alpha, SEXP Resample, SEXP CI, 
		  SEXP Faaa, SEXP PlugIn, SEXP Sizee, SEXP Beta, SEXP CVG, SEXP BS, 
		  SEXP OutMean, SEXP OutMin, SEXP OutMax, SEXP OutCvg);
