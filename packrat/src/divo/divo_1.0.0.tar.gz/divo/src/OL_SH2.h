double OL_SH2(int* ptrVec,int nVec,double Sum_dat);
