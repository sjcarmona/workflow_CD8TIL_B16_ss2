void DP_single_population_HT(int* ptrCol,int* ptrdimAfa,double* ptrAlphaPro,int nAlphaPro,int ENS,double* ptrResults);
