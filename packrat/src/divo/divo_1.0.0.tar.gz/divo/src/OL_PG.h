double OL_PG(int* ptrIcol,int* ptrJcol,int* ptrdimAfa,double Alpha,double Beta);
