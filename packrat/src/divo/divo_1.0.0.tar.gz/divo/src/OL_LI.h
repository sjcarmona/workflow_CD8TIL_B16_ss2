double OL_LI(int* ptrIcol,int* ptrJcol,int* ptrdimAfa);

