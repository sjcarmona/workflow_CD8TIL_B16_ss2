void OL_confidence_interval_IN(double* ptrResults1D,int nResults1D,double valCI,
	double* ptrOutMean,double* ptrOutMin,double* ptrOutMax);
