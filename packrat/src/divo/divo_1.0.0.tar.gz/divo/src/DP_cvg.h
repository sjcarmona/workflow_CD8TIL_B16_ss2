double DP_cvg(int* ptrCol,int* ptrdimAfa);
