double DP_HT(double* ptrFreq,int nFreq,double Alpha,int ENS,double Sum);
