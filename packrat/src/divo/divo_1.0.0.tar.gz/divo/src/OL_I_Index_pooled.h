double OL_I_Index_pooled(int* ptrAfa1D,int nAfa1D,int** ptrAfa,int* ptrdimAfa,double Alpha);
