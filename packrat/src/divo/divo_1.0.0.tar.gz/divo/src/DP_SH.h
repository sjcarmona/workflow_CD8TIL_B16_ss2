double DP_SH(double* ptrFreq,int nFreq);
