double OL_RD(int* ptrIcol,int* ptrJcol,int* ptrdimAfa,double Alpha);
