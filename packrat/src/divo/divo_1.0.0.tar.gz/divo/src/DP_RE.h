double DP_RE(double* ptrFreq,int nFreq,double Alpha,int ENS);
