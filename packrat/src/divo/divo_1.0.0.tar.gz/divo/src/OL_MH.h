double OL_MH(int* ptrIcol,int* ptrJcol,int* ptrdimAfa);
