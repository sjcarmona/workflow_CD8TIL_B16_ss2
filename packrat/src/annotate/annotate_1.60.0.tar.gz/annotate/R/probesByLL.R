probesByLL <- function(baseName, what = "ENTREZID")
    .Defunct("AnnotationDbi::select() for similar functionality")
