# DOSE 3.7.1

+ S3 accessor methods only return enriched terms. (2018-06-20, Wed)
