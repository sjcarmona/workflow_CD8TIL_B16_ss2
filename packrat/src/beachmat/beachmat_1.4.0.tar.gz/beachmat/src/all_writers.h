#ifndef BEACHMAT_OUTPUT_MATRIX_H
#define BEACHMAT_OUTPUT_MATRIX_H

#include "beachmat.h"
#include "utils.h"
#include "dim_checker.h"

#include "simple_writer.h"
#include "Csparse_writer.h"
#include "HDF5_writer.h"

#endif
