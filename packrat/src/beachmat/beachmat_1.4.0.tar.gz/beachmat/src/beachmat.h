#ifndef BEACHMAT_H
#define BEACHMAT_H

#include <vector>
#include <deque>
#include <algorithm>
#include <string>
#include <memory>
#include <stdexcept>
#include <sstream>
#include <cmath>
#include <tuple>

#include "Rcpp.h"
#include "H5Cpp.h"

#endif
