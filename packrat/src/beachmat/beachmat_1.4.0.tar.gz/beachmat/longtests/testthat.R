library(testthat)
library(beachmat)
test_check("beachmat")
