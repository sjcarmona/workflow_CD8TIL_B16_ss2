#' @importFrom Rcpp sourceCpp
#' @useDynLib beachmat, .registration=TRUE, .fixes="cxx_"
NULL
