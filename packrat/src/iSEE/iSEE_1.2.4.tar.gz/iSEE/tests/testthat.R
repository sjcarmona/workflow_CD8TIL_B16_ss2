library(testthat)
library(iSEE)

test_check("iSEE")
