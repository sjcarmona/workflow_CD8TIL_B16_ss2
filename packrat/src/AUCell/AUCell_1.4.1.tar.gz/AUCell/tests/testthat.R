library(testthat)
library(AUCell)

test_check("AUCell")
