#' @import SingleCellExperiment
#' @import BiocParallel
#' @importFrom Matrix rowSums colSums
#' @importFrom Rcpp sourceCpp
#' @useDynLib DropletUtils, .fixes="cxx_", .registration=TRUE
NULL
