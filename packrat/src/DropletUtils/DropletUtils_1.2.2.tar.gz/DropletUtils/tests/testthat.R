library(testthat)
library(DropletUtils)
test_check("DropletUtils")
